from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from statistics import mean

app=Flask(__name__)
app.secret_key="enterprisesigma-master-black-belt"
DB="enterprisesigma.db"

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=conn()
    with open("schema.sql","r",encoding="utf-8") as f: c.executescript(f.read())
    if c.execute("SELECT COUNT(*) FROM initiatives").fetchone()[0]==0:
        initiatives=[
            ("CNC Quality Stabilization","Manufacturing","Black Belt","In Progress",82,2.8,1.6,145000),
            ("Order Fulfillment Excellence","Operations","Green Belt","Completed",74,4.1,2.2,98000),
            ("Battery Assembly Yield","Energy","Black Belt","In Progress",91,3.4,1.9,172000),
            ("Invoice Cycle-Time Reduction","Finance","Yellow Belt","Completed",63,5.2,3.1,56000),
            ("Customer Resolution Improvement","Support","Green Belt","Planned",58,6.0,3.8,74000)]
        c.executemany("""INSERT INTO initiatives
        (name,department,belt,status,baseline_defect,target_defect,actual_defect,savings)
        VALUES (?,?,?,?,?,?,?,?)""",initiatives)
        actions=[
            (1,"Standardize machine setup","Analyze","High","Open",25000),
            (1,"Implement control monitoring","Control","Medium","In Progress",18000),
            (2,"Redesign fulfillment workflow","Improve","High","Closed",22000),
            (3,"Optimize thermal process window","Improve","High","In Progress",31000),
            (4,"Automate invoice validation","Improve","Medium","Closed",14000),
            (5,"Create service escalation matrix","Define","Medium","Open",12000)]
        c.executemany("""INSERT INTO actions
        (initiative_id,action,phase,priority,status,estimated_savings)
        VALUES (?,?,?,?,?,?)""",actions)
        risks=[
            (1,"Process drift","High","Medium",16,"Add SPC monitoring"),
            (1,"Training variation","Medium","Medium",9,"Standard work training"),
            (3,"Temperature instability","High","High",20,"Automated parameter alerts"),
            (5,"Adoption resistance","Medium","Low",5,"Change-management workshops")]
        c.executemany("""INSERT INTO risks
        (initiative_id,risk,likelihood,impact,risk_score,mitigation)
        VALUES (?,?,?,?,?,?)""",risks)
    c.commit(); c.close()

@app.route("/")
def dashboard():
    c=conn()
    initiatives=c.execute("SELECT * FROM initiatives ORDER BY id").fetchall()
    actions=c.execute("SELECT * FROM actions ORDER BY id DESC").fetchall()
    risks=c.execute("SELECT * FROM risks ORDER BY risk_score DESC").fetchall()
    total=c.execute("SELECT COALESCE(SUM(savings),0) FROM initiatives").fetchone()[0]
    completed=c.execute("SELECT COUNT(*) FROM initiatives WHERE status='Completed'").fetchone()[0]
    avg_improvement=c.execute("SELECT AVG(baseline_defect-actual_defect) FROM initiatives").fetchone()[0] or 0
    open_actions=c.execute("SELECT COUNT(*) FROM actions WHERE status!='Closed'").fetchone()[0]
    high_risk=c.execute("SELECT COUNT(*) FROM risks WHERE risk_score>=15").fetchone()[0]
    c.close()
    return render_template("dashboard.html",initiatives=initiatives,actions=actions,risks=risks,
                           total=total,completed=completed,avg_improvement=avg_improvement,
                           open_actions=open_actions,high_risk=high_risk)

@app.route("/initiatives",methods=["GET","POST"])
def initiatives():
    c=conn()
    if request.method=="POST":
        c.execute("""INSERT INTO initiatives
        (name,department,belt,status,baseline_defect,target_defect,actual_defect,savings)
        VALUES (?,?,?,?,?,?,?,?)""",
        (request.form["name"],request.form["department"],request.form["belt"],
         request.form["status"],float(request.form["baseline_defect"]),
         float(request.form["target_defect"]),float(request.form["actual_defect"]),
         float(request.form["savings"])))
        c.commit(); c.close(); flash("Improvement initiative added.")
        return redirect(url_for("initiatives"))
    data=c.execute("SELECT * FROM initiatives ORDER BY id DESC").fetchall()
    c.close(); return render_template("initiatives.html",initiatives=data)

@app.route("/actions",methods=["GET","POST"])
def actions():
    c=conn()
    if request.method=="POST":
        c.execute("""INSERT INTO actions
        (initiative_id,action,phase,priority,status,estimated_savings)
        VALUES (?,?,?,?,?,?)""",
        (int(request.form["initiative_id"]),request.form["action"],request.form["phase"],
         request.form["priority"],request.form["status"],float(request.form["estimated_savings"])))
        c.commit(); c.close(); flash("Improvement action added.")
        return redirect(url_for("actions"))
    data=c.execute("""SELECT a.*,i.name initiative_name FROM actions a
                      JOIN initiatives i ON i.id=a.initiative_id ORDER BY a.id DESC""").fetchall()
    initiatives=c.execute("SELECT * FROM initiatives ORDER BY name").fetchall()
    c.close(); return render_template("actions.html",actions=data,initiatives=initiatives)

@app.route("/risks",methods=["GET","POST"])
def risks():
    c=conn()
    if request.method=="POST":
        likelihood=request.form["likelihood"]; impact=request.form["impact"]
        scale={"Low":1,"Medium":2,"High":3}
        score=scale[likelihood]*scale[impact]
        c.execute("""INSERT INTO risks
        (initiative_id,risk,likelihood,impact,risk_score,mitigation)
        VALUES (?,?,?,?,?,?)""",
        (int(request.form["initiative_id"]),request.form["risk"],likelihood,impact,score,
         request.form["mitigation"]))
        c.commit(); c.close(); flash("Risk registered.")
        return redirect(url_for("risks"))
    data=c.execute("""SELECT r.*,i.name initiative_name FROM risks r
                      JOIN initiatives i ON i.id=r.initiative_id ORDER BY r.risk_score DESC""").fetchall()
    initiatives=c.execute("SELECT * FROM initiatives ORDER BY name").fetchall()
    c.close(); return render_template("risks.html",risks=data,initiatives=initiatives)

@app.route("/portfolio")
def portfolio():
    c=conn()
    rows=c.execute("""SELECT department,COUNT(*) count,SUM(savings) savings,
                      AVG(baseline_defect-actual_defect) improvement
                      FROM initiatives GROUP BY department ORDER BY savings DESC""").fetchall()
    belts=c.execute("""SELECT belt,COUNT(*) count,SUM(savings) savings
                       FROM initiatives GROUP BY belt ORDER BY savings DESC""").fetchall()
    c.close(); return render_template("dashboard.html", initiatives=[], actions=[], risks=[], total=0, completed=0, avg_improvement=0, open_actions=0, high_risk=0)

@app.route("/delete/<table>/<int:item_id>")
def delete_item(table,item_id):
    allowed={"initiatives":"initiatives","actions":"actions","risks":"risks"}
    if table not in allowed: return redirect(url_for("dashboard"))
    c=conn(); c.execute(f"DELETE FROM {allowed[table]} WHERE id=?",(item_id,)); c.commit(); c.close()
    flash("Record removed."); return redirect(url_for(table))

if __name__=="__main__":
    init_db(); app.run(debug=True)
