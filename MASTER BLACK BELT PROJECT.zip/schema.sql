CREATE TABLE IF NOT EXISTS initiatives(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 department TEXT NOT NULL,
 belt TEXT NOT NULL,
 status TEXT NOT NULL,
 baseline_defect REAL NOT NULL,
 target_defect REAL NOT NULL,
 actual_defect REAL NOT NULL,
 savings REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS actions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 initiative_id INTEGER NOT NULL,
 action TEXT NOT NULL,
 phase TEXT NOT NULL,
 priority TEXT NOT NULL,
 status TEXT NOT NULL,
 estimated_savings REAL DEFAULT 0,
 FOREIGN KEY(initiative_id) REFERENCES initiatives(id)
);

CREATE TABLE IF NOT EXISTS risks(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 initiative_id INTEGER NOT NULL,
 risk TEXT NOT NULL,
 likelihood TEXT NOT NULL,
 impact TEXT NOT NULL,
 risk_score INTEGER NOT NULL,
 mitigation TEXT,
 FOREIGN KEY(initiative_id) REFERENCES initiatives(id)
);
