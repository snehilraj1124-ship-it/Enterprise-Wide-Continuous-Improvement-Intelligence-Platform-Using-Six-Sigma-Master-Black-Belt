# Enterprise-Wide Continuous Improvement Intelligence Platform using Six Sigma Master Black Belt

## Overview

EnterpriseSigma is a full-stack Six Sigma Master Black Belt portfolio project for managing continuous-improvement initiatives across an organization.

The platform moves beyond individual process projects and provides an enterprise-level view of:

- Improvement initiatives
- Six Sigma belt deployment
- DMAIC action plans
- Financial savings
- Department-level improvement
- Risk management
- Portfolio performance
- Improvement governance

It is designed to demonstrate how a Master Black Belt can connect multiple improvement projects into a structured enterprise continuous-improvement system.

## Objectives

- Manage improvement initiatives across departments.
- Track Six Sigma belt-level deployment.
- Monitor baseline and actual defect performance.
- Compare projects against improvement targets.
- Track improvement actions across DMAIC phases.
- Estimate project savings.
- Identify and score improvement risks.
- Track mitigation plans.
- Analyze improvement performance by department.
- Analyze portfolio performance by Six Sigma belt.
- Provide an executive-level improvement dashboard.

## Master Black Belt Concepts

### Enterprise Governance

Master Black Belt work extends beyond one process. The platform provides a portfolio view of projects across:

- Manufacturing
- Operations
- Energy
- Finance
- Support

This enables structured governance of improvement initiatives.

### DMAIC Governance

Improvement actions can be mapped to:

- Define
- Measure
- Analyze
- Improve
- Control

This creates visibility into where each improvement initiative is progressing.

### Financial Impact

Each initiative stores an estimated savings value.

The dashboard aggregates project-level savings to provide an enterprise portfolio view.

Real financial validation should include:

- Baseline validation
- Hard savings
- Soft savings
- Implementation cost
- Labor impact
- Throughput impact
- Quality-cost reduction
- Finance approval

### Risk Management

Each project can have multiple risks.

Risk score is calculated using:

`Risk Score = Likelihood × Impact`

The application maps:

- Low = 1
- Medium = 2
- High = 3

The resulting score helps prioritize mitigation activities.

## Core Modules

### 1. Enterprise Dashboard

Displays:

- Total improvement value
- Completed initiatives
- Average defect-rate improvement
- Open actions
- High-risk items
- Initiative portfolio
- Recent improvement actions
- Risk register

### 2. Initiative Management

Track:

- Initiative name
- Department
- Six Sigma belt
- Status
- Baseline defect rate
- Target defect rate
- Actual defect rate
- Estimated savings

### 3. Improvement Action Management

Track:

- Action
- DMAIC phase
- Priority
- Status
- Estimated savings
- Associated initiative

### 4. Risk Register

Track:

- Risk
- Likelihood
- Impact
- Risk score
- Mitigation
- Associated initiative

### 5. Portfolio Analytics

Analyze improvement performance by:

- Department
- Six Sigma belt
- Estimated savings
- Average defect-rate improvement

## Portfolio Metrics

### Defect Improvement

For each initiative:

`Defect Improvement = Baseline Defect Rate − Actual Defect Rate`

A positive value indicates reduction in the observed defect rate.

### Risk Score

`Risk Score = Likelihood × Impact`

### Portfolio Savings

`Portfolio Savings = Sum of Initiative Savings`

These metrics are intended for portfolio-level management and should be validated against organizational finance and quality systems in real deployments.

## Six Sigma Belt Deployment

EnterpriseSigma supports a structured improvement hierarchy:

### White Belt
Awareness and basic process-improvement participation.

### Yellow Belt
Team-level problem solving and defect/root-cause analysis.

### Green Belt
Data-driven process improvement and statistical analysis.

### Black Belt
Advanced improvement projects, optimization, predictive analysis, and cross-functional leadership.

### Master Black Belt
Enterprise governance, coaching, methodology deployment, portfolio management, and continuous-improvement strategy.

## Technology Stack

- Python
- Flask
- SQLite
- Jinja2
- HTML5
- CSS3
- Six Sigma DMAIC
- Portfolio Analytics
- Risk Management

## Project Structure

```text
EnterpriseSigma/
├── app.py
├── requirements.txt
├── README.md
├── schema.sql
├── .gitignore
└── templates/
    ├── base.html
    ├── dashboard.html
    ├── initiatives.html
    ├── actions.html
    ├── risks.html
    └── portfolio.html
```

## Installation

### 1. Clone

```bash
git clone <your-repository-url>
cd EnterpriseSigma
```

### 2. Create Virtual Environment

Windows:

```bash
python -m venv venv
venv\Scriptsctivate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run

```bash
python app.py
```

Open:

`http://127.0.0.1:5000`

The database is automatically initialized with demonstration data.

## Example Enterprise Workflow

```text
Identify Improvement Opportunities
              ↓
Prioritize Portfolio
              ↓
Assign Six Sigma Belt
              ↓
Define DMAIC Actions
              ↓
Track Project Performance
              ↓
Monitor Financial Value
              ↓
Assess Project Risks
              ↓
Apply Mitigation
              ↓
Validate Improvements
              ↓
Control & Sustain
              ↓
Enterprise Portfolio Review
```

## Example Use Cases

### Manufacturing
Manage multiple quality and productivity projects across production lines.

### Energy
Track improvement initiatives involving asset reliability, yield, efficiency, and operating performance.

### Operations
Manage cycle-time, fulfillment, service-quality, and process-efficiency initiatives.

### Finance
Track process automation, invoice-quality, cycle-time, and error-reduction initiatives.

### Customer Support
Monitor service-resolution and customer-process improvement programs.

## Future Enhancements

- Project charter management
- CTQ tree management
- SIPOC mapping
- Value-stream mapping
- Advanced KPI dashboards
- Control-plan management
- Statistical process control
- MSA tracking
- DOE management
- Automated project scoring
- Benefit-realization tracking
- Finance approval workflow
- Executive reports
- User authentication
- Role-based permissions
- Audit trails
- CSV/Excel import
- Power BI integration
- Real-time enterprise data connectors
- Machine-learning opportunity detection
- Automated portfolio prioritization

## Master Black Belt Portfolio Progression

This project represents the fifth and final stage of the Six Sigma portfolio:

1. White Belt — Operational Process Mapping & Waste Intelligence
2. Yellow Belt — Quality Defect & Root Cause Analysis
3. Green Belt — Process Capability & Statistical Quality Analytics
4. Black Belt — Advanced Process Optimization & Predictive Quality
5. Master Black Belt — Enterprise-Wide Continuous Improvement Intelligence

## Learning Outcomes

This project demonstrates:

- Enterprise continuous-improvement thinking
- Six Sigma governance
- DMAIC portfolio management
- Cross-functional improvement tracking
- Financial impact analysis
- Risk prioritization
- Improvement-action management
- Executive analytics
- Flask application development
- SQLite data modeling
- Operational decision support

## Disclaimer

This is an educational portfolio project.

The savings, defect metrics, risk scores, and demonstration data are illustrative. Real enterprise deployment requires validated baselines, statistical analysis, finance approval, process-owner validation, governance controls, and integration with authoritative organizational systems.

## Author

Snehil Raj

B.Tech Electrical & Electronics Engineering

Focus Areas:
- Data Analytics
- Business Analytics
- Operations
- Energy Systems
- Process Improvement
- Six Sigma
- Continuous Improvement

## License

For educational, portfolio, and demonstration purposes.
